Hello,
In order to understand how the project works please read first out algorithm draft then 
read the comments on the project itself. 
if you don't have a specific test cases we have attached a file called Test Cases which contains some test cases with thier correct expected output you can check them .
